Full scraper live retest evidence, 2026-11-04.

results/ contains complete typed row output and comparison for every full run, including repeats and mismatches. summary.json indexes all runs, including the three additional Hot Cinema comparisons after the date-coverage correction. sources/ contains captured HTTP responses for MovieLand showtimes, Hot Cinema showtimes (initial and corrected collectors), and Holon, where discrepancies or live failures required diagnosis. Exact successful runs for other scrapers retain complete output rows but omit raw source payloads.

The comparison ignores only generated run_id and snapshot_id fields; duplicate rows and all other values/types are preserved.
