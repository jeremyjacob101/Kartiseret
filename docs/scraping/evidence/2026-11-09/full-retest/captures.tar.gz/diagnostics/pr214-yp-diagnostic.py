from pathlib import Path
import json
from backend.scraping.compare import collect
from backend.scraping.nowplayings.YesPlanet import YesPlanet
original=YesPlanet.scrapeQuickbookShowtimes
records=[]
def wrapped(self,names):
 if self.date_of_showing in ('2026-12-16','2026-12-17','2026-12-18','2026-12-19'):
  data=self.driver.execute_script("""const node=document.querySelector('.qb-by-cinema');const vm=node?.__vue__;return {url:location.href,models:vm?{name:vm.$options.name,selectedDate:vm.selectedDate,selectedFilter:vm.selectedFilter,movies:vm.movies,events:vm.events,allMovies:vm.allMovies}:null,cards:Array.from(document.querySelectorAll('section.npm-quickbook .movie-row')).filter(f=>/avengers/i.test(f.textContent)).map(f=>({text:f.textContent,tickets:f.querySelectorAll('a[data-url]').length,html:f.outerHTML})),resources:performance.getEntriesByType('resource').filter(x=>x.name.includes('/film-events')).map(x=>x.name)}""")
  data.update(date=self.date_of_showing,city=self.screening_city,catalog_avengers={k:v for k,v in names.items() if 'avengers' in k})
  records.append(data);Path('/private/tmp/pr214-yp-diagnostic-dom.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
 return original(self,names)
YesPlanet.scrapeQuickbookShowtimes=wrapped
result=collect(YesPlanet,'selenium');Path('/private/tmp/pr214-yp-diagnostic-output.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result['status'],len(result.get('rows',[])),result.get('error'))
