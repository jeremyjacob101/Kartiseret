import pathlib,json,gzip,base64,importlib
from backend.scraping.compare import collect,compare_rows
from backend.scraping.nowplayings.CinemaCity import CinemaCity
root=pathlib.Path('/private/tmp/pr214-cinema-city-recheck-20261109')
pair=json.loads(next(root.glob('CinemaCity-*.json')).read_text())
expected=[item['row'] for item in pair['comparison']['requests_only'] for _ in range(item['count'])]
titles={r['hebrew_title'] for r in expected}; ids={}
def scan(x):
 if isinstance(x,dict):
  if isinstance(x.get('name'),str) and 'externalId' in x:
   for title in titles:
    if title in x['name']:ids[title]=str(x['externalId'])
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
for p in (root/'sources'/'CinemaCity').glob('*/source*'):
 for line in gzip.open(p,'rt'):
  r=json.loads(line)
  try:scan(json.loads(base64.b64decode(r['body_base64'])))
  except (ValueError,UnicodeDecodeError):pass
assert set(ids)==titles,(ids,titles)
class Card:
 def __init__(self,value):self.value=value
 def get_attribute(self,name):
  assert name=='id'
  return 'comp-mpkxxq0h__'+self.value
original=CinemaCity.elements
CinemaCity.elements=lambda self,path,*args: [Card(x) for x in ids.values()] if path=="[id^='comp-mpkxxq0h__']" else original(self,path,*args)
module=importlib.import_module('backend.scraping.nowplayings.CinemaCity');module.load_movie_listing=lambda *args:None
result=collect(CinemaCity,'selenium');comparison=compare_rows(result.get('rows',[]),expected)
output={'purpose':'Independent direct movie-page Selenium verification of extra films, not a complete baseline parity pass','film_ids':ids,'selenium':result,'expected_extra_rows':expected,'comparison':comparison}
pathlib.Path('/private/tmp/pr214-cc-extra-proof.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
print(result['status'],result.get('error'),len(result.get('rows',[])),comparison['matched'],len(comparison['selenium_only']),len(comparison['requests_only']),flush=True)
