import base64,gzip,json,glob,time,pathlib
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from backend.scraping.comingsoons.CCsoon import CCsoon
from backend.scraping.nowplayings.CinemaCity import CinemaCity
from backend.scraping.utils.InitializeBaseCinema import InitializeBaseCinema,build_chrome,navigate
from backend.scraping.utils.CinemaCityRequests import _coming_soon_title
from backend.scraping.compare import rows_from_columns,compare_rows
out=pathlib.Path('/private/tmp/pr214-cc-release-proof')
comparison=json.load(open(glob.glob('/private/tmp/pr214-release-parity-20261107/CCsoon-*.json')[0]))
extras=[x['row'] for x in comparison['comparison']['requests_only']]
features=[]
for p in glob.glob('/private/tmp/pr214-release-parity-20261107/sources/CCsoon/*/*.gz'):
 for line in gzip.open(p,'rt'):
  x=json.loads(line);body=json.loads(base64.b64decode(x['body_base64']))
  features += [item['data'] for item in body.get('dataItems',[]) if 'dateStarted' in item.get('data',{})]
targets=[]
for feature in features:
 title=_coming_soon_title(feature.get('name'))
 if any(r['hebrew_title']==title and r['english_title']==((feature.get('additionalName') or '').replace('\u200b','').strip() or title) for r in extras):targets.append(feature)
d=build_chrome(True);d.set_page_load_timeout(45);result={'membership':{},'details':[]}
try:
 d.get(CCsoon.URL);wait=WebDriverWait(d,20)
 cards="[id^='comp-mrjafvop__']";button="//button[normalize-space()='תראו לי עוד סרטים']"
 wait.until(lambda _:d.find_elements(By.CSS_SELECTOR,cards));time.sleep(2)
 for _ in range(20):
  buttons=d.find_elements(By.XPATH,button);visible=[b for b in buttons if b.is_displayed()]
  if not visible:
   time.sleep(1)
   visible=[b for b in d.find_elements(By.XPATH,button) if b.is_displayed()]
   if not visible:break
  n=len(d.find_elements(By.CSS_SELECTOR,cards));d.execute_script('arguments[0].scrollIntoView({block:"center"});',visible[0]);visible[0].click()
  wait.until(lambda _:len(d.find_elements(By.CSS_SELECTOR,cards))>n);time.sleep(.3)
 else:raise RuntimeError('Pagination did not terminate')
 ids=[e.get_attribute('id').split('__')[-1] for e in d.find_elements(By.CSS_SELECTOR,cards)]
 result['membership']={'count':len(ids),'ids':ids,'load_more_visible':any(b.is_displayed() for b in d.find_elements(By.XPATH,button))}
 (out/'coming-soon-list.html').write_text(d.page_source)
 for f in targets:
  fid=str(f['externalId']);d.get('https://www.cinema-city.co.il/movie/'+fid);time.sleep(.6)
  record={'id':fid,'listed':fid in ids,'url':d.current_url,'title':d.title}
  for name,selector in [('hebrew','main h1'),('english','#comp-mkb98jrw'),('runtime','#comp-mkbdaczu'),('rating','#comp-mkbdcdtv'),('release','#comp-mkbdbb73')]:
   els=d.find_elements(By.CSS_SELECTOR,selector);record[name]=els[0].get_attribute('textContent') if els else None
  result['details'].append(record);print(json.dumps(record,ensure_ascii=False),flush=True)
  (out/(fid+'.html')).write_text(d.page_source)
 (out/'coming-soon-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
finally:d.quit()
# Run the unchanged browser collector on the one API-discovered film omitted
# by homepage traversal. Its real movie-page controls provide independent proof.
s=CinemaCity.__new__(CinemaCity);InitializeBaseCinema.__init__(s);s.run_id=0;s.driver=build_chrome(True)
try:
 navigate(s);s.hebrew_hrefs=['https://www.cinema-city.co.il/movie/6695']
 elements=s.elements
 s.elements=lambda path,*a,**k: [] if path=="[id^='comp-mpkxxq0h__']" else elements(path,*a,**k)
 s.logic();rows=rows_from_columns(s.gathering_info)
 expected=json.load(open(glob.glob('/private/tmp/pr214-release-parity-20261107/CinemaCity-*.json')[0]))['comparison']['requests_only']
 expected=[x['row'] for x in expected]
 proof={'rows':rows,'comparison':compare_rows(rows,expected)}
 (out/'showtimes-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2));print('showtimes',len(rows),proof['comparison'],flush=True)
finally:s.driver.quit()
