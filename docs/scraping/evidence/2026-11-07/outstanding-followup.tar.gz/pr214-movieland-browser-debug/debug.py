import json,time,pathlib,traceback
from selenium.webdriver.common.by import By
from backend.scraping.utils.InitializeBaseCinema import build_chrome
out=pathlib.Path('/private/tmp/pr214-movieland-browser-debug')
d=build_chrome(True)
d.set_page_load_timeout(45)
try:
 d.get('https://movieland.co.il/movies')
 states=[]
 for elapsed in (0,10,25,45):
  if elapsed:time.sleep(elapsed-states[-1]['elapsed'])
  state={'elapsed':elapsed,'url':d.current_url,'title':d.title,'cards':len(d.find_elements(By.CSS_SELECTOR,'#change-bg .movies-page a[poster-summary]')),'text':d.find_element(By.TAG_NAME,'body').text[:2500]}
  states.append(state)
  print(json.dumps(state,ensure_ascii=False),flush=True)
  d.save_screenshot(str(out/f'page-{elapsed}.png'))
  (out/f'page-{elapsed}.html').write_text(d.page_source)
  if state['cards']:break
 (out/'states.json').write_text(json.dumps(states,ensure_ascii=False,indent=2))
 (out/'browser-log.json').write_text(json.dumps(d.get_log('browser'),ensure_ascii=False,indent=2))
except Exception:
 print(traceback.format_exc(),flush=True)
finally:d.quit()
